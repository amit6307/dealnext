NEHA CALL REQUEST WEBSITE

How to use:
1. Extract this ZIP file.
2. Open index.html in a web browser to test the website.
3. To share it as a public link, upload index.html to a static website host such as Netlify Drop (https://app.netlify.com/drop) or use CodePen.

Note: The buttons show messages on the page. They do not place a phone call automatically.
