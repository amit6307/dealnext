const $ = (s) => document.querySelector(s);
const money = n => "₹" + Number(n||0).toLocaleString("en-IN",{maximumFractionDigits:2});
const state = JSON.parse(localStorage.getItem("sellerpilot") || '{"products":[],"orders":[],"user":null}');
const save=()=>localStorage.setItem("sellerpilot",JSON.stringify(state));

function layout(content, active="dashboard"){
  const nav=[["dashboard","Dashboard"],["calculator","Profit Calculator"],["products","Products"],["orders","Orders"],["rto","RTO Tracker"],["pricing","Pricing"]];
  return `<div class="shell">
  <aside><div class="brand">Seller<span>Pilot</span></div><div class="muted">Seller operating toolkit</div>
  <nav>${nav.map(([id,t])=>`<button class="${active===id?'active':''}" onclick="route('${id}')">${t}</button>`).join("")}</nav>
  <div class="sidebox"><b>Demo account</b><small>Data is stored only in this browser.</small></div>
  </aside>
  <main><header><div><div class="eyebrow">SELLERPILOT</div><h1>${nav.find(x=>x[0]===active)?.[1]||"Dashboard"}</h1></div><button class="ghost" onclick="resetDemo()">Reset demo</button></header>${content}</main></div>`;
}

function route(p){ location.hash=p; render(); }
function render(){
  const p=location.hash.replace("#","")||"dashboard";
  const pages={dashboard,calculator,products,orders,rto,pricing};
  $("#app").innerHTML=layout((pages[p]||dashboard)(),p);
}
function dashboard(){
  const revenue=state.orders.reduce((a,o)=>a+o.selling,0);
  const profit=state.orders.reduce((a,o)=>a+o.profit,0);
  const rto=state.orders.filter(o=>o.status==="RTO").length;
  return `<section class="hero"><div><h2>Know your real margin.</h2><p>Track product economics, order profit and RTO impact in one place.</p></div><button onclick="route('calculator')">Calculate profit →</button></section>
  <div class="grid4"><div class="card"><span>Revenue</span><b>${money(revenue)}</b></div><div class="card"><span>Net profit</span><b>${money(profit)}</b></div><div class="card"><span>Orders</span><b>${state.orders.length}</b></div><div class="card"><span>RTO orders</span><b>${rto}</b></div></div>
  <div class="two"><div class="card"><h3>What to use first</h3><div class="list"><button onclick="route('calculator')">Profit calculator <small>Find actual margin before listing.</small></button><button onclick="route('products')">Product tracker <small>Keep cost and selling price in one place.</small></button><button onclick="route('rto')">RTO tracker <small>See how returns eat margin.</small></button></div></div>
  <div class="card"><h3>Recent orders</h3>${state.orders.length?state.orders.slice(-5).reverse().map(o=>`<div class="row"><span>${o.product}</span><b>${money(o.profit)}</b></div>`).join(""):"<p class='muted'>No orders yet. Add one from Orders.</p>"}</div></div>`;
}
function calculator(){
 return `<div class="card formcard"><h2>Order profit calculator</h2><p class="muted">Use your actual marketplace, shipping and return assumptions.</p>
 <div class="formgrid">${input("Product cost","cost","1000")}${input("Selling price","price","1999")}${input("Marketplace fee %","fee","15")}${input("Shipping","ship","80")}${input("GST / tax","tax","0")}${input("Expected RTO cost","rto","30")}</div>
 <button onclick="calc()">Calculate</button><div id="calcResult" class="result"></div></div>`;
}
function input(label,id,value=""){return `<label>${label}<input id="${id}" type="number" step="0.01" value="${value}"></label>`}
function calc(){
 const c=+$("#cost").value,p=+$("#price").value,f=p*(+$("#fee").value/100),s=+$("#ship").value,t=+$("#tax").value,r=+$("#rto").value;
 const profit=p-c-f-s-t-r, margin=p?profit/p*100:0;
 $("#calcResult").innerHTML=`<div class="profit ${profit>=0?'good':'bad'}"><span>Estimated net profit</span><b>${money(profit)}</b><small>Margin: ${margin.toFixed(1)}%</small></div>`;
}
function products(){
 return `<div class="card"><h2>Add product</h2><div class="formgrid">${input("Product name","pn","Solar Street Light")}${input("Cost","pc","1000")}${input("Selling price","pp","1999")}</div><button onclick="addProduct()">Save product</button></div>
 <div class="card"><h3>Your products</h3>${state.products.length?`<table><tr><th>Product</th><th>Cost</th><th>Price</th><th>Gross margin</th></tr>${state.products.map(p=>`<tr><td>${p.name}</td><td>${money(p.cost)}</td><td>${money(p.price)}</td><td>${money(p.price-p.cost)} (${((p.price-p.cost)/p.price*100).toFixed(1)}%)</td></tr>`).join("")}</table>`:"<p class='muted'>No products saved.</p>"}</div>`;
}
function addProduct(){const name=$("#pn").value.trim(); if(!name)return alert("Enter product name");state.products.push({name,cost:+$("#pc").value,price:+$("#pp").value});save();render();}
function orders(){
 return `<div class="card"><h2>Add order</h2><div class="formgrid">${input("Product","on","Solar Street Light")}${input("Selling price","op","1999")}${input("Product cost","oc","1000")}${input("Marketplace + shipping","of","380")}</div><label>Status<select id="os"><option>Delivered</option><option>RTO</option><option>Cancelled</option></select></label><button onclick="addOrder()">Save order</button></div>
 <div class="card"><h3>Orders</h3>${state.orders.length?`<table><tr><th>Product</th><th>Status</th><th>Sale</th><th>Profit</th></tr>${state.orders.map(o=>`<tr><td>${o.product}</td><td><span class="tag">${o.status}</span></td><td>${money(o.selling)}</td><td>${money(o.profit)}</td></tr>`).join("")}</table>`:"<p class='muted'>No orders saved.</p>"}</div>`;
}
function addOrder(){const p=$("#op").value,c=$("#oc").value,f=$("#of").value,status=$("#os").value;const profit=+p-+c-+f-(status==="RTO"?50:0);state.orders.push({product:$("#on").value,selling:+p,profit,status});save();render();}
function rto(){
 const total=state.orders.length, rt=state.orders.filter(o=>o.status==="RTO").length;
 const rate=total?rt/total*100:0;
 return `<div class="grid3"><div class="card"><span>Total orders</span><b>${total}</b></div><div class="card"><span>RTO orders</span><b>${rt}</b></div><div class="card"><span>RTO rate</span><b>${rate.toFixed(1)}%</b></div></div>
 <div class="card"><h2>RTO control</h2><p>Record every RTO and compare its cost with your product margin. High RTO can make a product look profitable on paper while losing money in reality.</p><ul><li>Track RTO rate by SKU.</li><li>Separate forward and return shipping.</li><li>Review COD-heavy pincodes.</li></ul></div>`;
}
function pricing(){
 return `<div class="pricing"><div class="price card"><h2>Free</h2><b>₹0</b><p>Basic calculators and limited tracking.</p><button class="ghost">Current</button></div>
 <div class="price card featured"><span class="tag">Recommended</span><h2>Pro</h2><b>₹199<span>/month</span></b><p>Unlimited products, orders, reports and seller dashboard.</p><button onclick="demoSubscribe()">Start Pro demo</button></div>
 <div class="price card"><h2>Annual</h2><b>₹1,999<span>/year</span></b><p>Save versus monthly billing.</p><button onclick="demoSubscribe()">Choose annual</button></div></div>
 <div class="card"><h3>Important before launch</h3><p>These buttons are demo-only. For real subscriptions, connect a payment provider and a server-side webhook; never trust browser-side payment status.</p></div>`;
}
function demoSubscribe(){alert("Demo subscription activated locally. No real payment was made.");}
function resetDemo(){if(confirm("Delete demo data from this browser?")){localStorage.removeItem("sellerpilot");location.reload();}}
window.route=route;window.render=render;window.calc=calc;window.addProduct=addProduct;window.addOrder=addOrder;window.demoSubscribe=demoSubscribe;window.resetDemo=resetDemo;
window.addEventListener("hashchange",render); render();
